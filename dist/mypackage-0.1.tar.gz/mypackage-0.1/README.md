# mypackage
This library was created as an example of how to publish your Python package.

# How to install
...